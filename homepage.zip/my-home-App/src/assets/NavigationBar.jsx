const NavigationBar = () => {
    return (
            <nav className="navigasi">
                <ul className="nav">
                    <li>Semua Kelas</li>
                    <li>Pemasaran</li>
                    <li>Desain</li>
                    <li>Pengembangan Diri</li>
                    <li>Bisnis</li>
                </ul>
            </nav>
    );
}

export default NavigationBar;