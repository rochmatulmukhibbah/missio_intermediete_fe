const InputPsswrd = (props) => {
    return (
        <div>
            <p>{props.name}</p>
            <input type="password"></input>
        </div>
    )
}

export default InputPsswrd;