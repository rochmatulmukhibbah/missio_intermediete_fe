const MyButton = (props) => {
    return (
        <div>
            <button>{props.click}</button>
        </div>
    );
}

export default MyButton;